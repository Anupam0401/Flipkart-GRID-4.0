import tweets
import time

tweets.books_Stationaries()
time.sleep(20*60)
tweets.electronics()
time.sleep(20*60)
tweets.home_Funiture()
time.sleep(20*60)
tweets.sports_More()
time.sleep(20*60)
tweets.beauTy()
time.sleep(20*60)
tweets.kids_Babies()                                    
time.sleep(20*60)
tweets.Fashion()
print("Execution Completed sucessfully!!")

